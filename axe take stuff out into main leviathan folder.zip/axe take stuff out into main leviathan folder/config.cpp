class CfgPatches
{
	class FC_Leviathan
	{
		units[] = {};
		weapons[] = {};
		requiredVersion = 0.1;
		requiredAddons[] = {"DZ_Weapons_Melee"};
	};
};
class CfgMods
{
	class FC_Leviathan
	{	
		
		dir = "clouds_weapons";
		picture = "";
		action = "";
		hideName = 1;
		hidePicture = 1;
		name = "FC_Leviathan Module";
		type = "mod";
	};
};

class CfgVehicles
{
    class Hatchet;
    class FC_Leviathan_Base: Hatchet
	{
		scope = 0;
		displayName = "Leviathan Axe";
		descriptionShort = "";
		model = "Testing1\leviathan\la.p3d";
		inventorySlot[]=
		{
			"Shoulder",
			"Melee"
		};
		SingleUseActions[]={533};
		ContinuousActions[]={168,193};
		build_action_type=10;
		dismantle_action_type=0;
		rotationFlags=17;
		weight=940;
		itemSize[]={2,3};
		fragility=0.0080000004;
		openItemSpillRange[]={0,0};
	};
    class FC_Leviathan: FC_Leviathan_Base
    {
        scope = 2;
		displayName="Leviathan Axe";
		descriptionShort="";
		hiddenSelections[]=
        {
		  "leviathan"
        };
        hiddenSelectionsTextures[] =
        {
            "Testing1\leviathan\data\base_ca.paa"
		};
    };
	class FC_Sparkles_Leviathan: FC_Leviathan_Base
    {
        scope = 2;
		displayName="Leviathan Axe";
		descriptionShort="";
		hiddenSelections[]=
        {
		  "leviathan"
        };
        hiddenSelectionsTextures[] =
        {
            "Testing1\leviathan\textures\Sparkles_Leviathan.paa"
		};
    };
};
